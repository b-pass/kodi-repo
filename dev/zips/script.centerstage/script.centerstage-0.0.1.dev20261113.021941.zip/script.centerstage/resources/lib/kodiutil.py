# -*- coding: utf-8 -*-
"""Everything that touches Kodi's Python modules, shared by the window, the context menu and the
widget listing."""
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import catalog
from jsonrpc import Rpc, RpcError
from model import (LIBRARY, MOVIE, MOVIES, MOVIES_ID, NEWEST, PVR, details_code,
                   episode_code, format_time, parse_date, plain)
from sources import pvr

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
# the empty stage (tools/art.py), for titles with no picture of their own
STAGE_ART = os.path.join(ADDON_PATH, 'resources', 'stage.jpg')
SPINNER = os.path.join(ADDON_PATH, 'resources', 'spinner.png')  # the busy spinner (tools/art.py)
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE_DIR = os.path.join(PROFILE, 'cache')
WINDOW_HOME = 10000

# strings.po ids
S = {
    'add_show': 32002, 'add_season': 32003, 'add_movie': 32004, 'add_episode': 32005,
    'add_folder': 32006, 'add_item': 32039, 'remove_named': 32007, 'added': 32008,
    'already': 32009, 'removed': 32010, 'show_name': 32011, 'confirm_name': 32012,
    'pvr_already': 32013, 'unhide_named': 32014, 'nothing': 32015, 'folder_name': 32038,
    'from_start': 32021, 'remove': 32022, 'rename': 32023,
    'refresh': 32024, 'hide_pvr': 32025, 'show_hidden': 32026,
    'load_failed': 32030, 'no_episodes': 32031,
    'library': 32032, 'pvr': 32033, 'watched': 32034, 'left': 32035, 'recordings': 32036,
    'play_failed': 32040, 'one_recording': 32041, 'season_watched': 32042,
    'season_episode': 32043, 'episode_n': 32044, 'group': 32045, 'all_groups': 32046,
    'which_group': 32048, 'set_group': 32049, 'switch_group': 32050, 'movies': 32051,
    'one_movie': 32052, 'n_movies': 32053, 'disk_used': 32054, 'newest': 32055,
    'settings': 32058, 'show_watched': 32059, 'hide_watched': 32107, 'cant_delete': 32114,
    'open_in': 32116,
}


def tr(key, *args):
    text = ADDON.getLocalizedString(S[key])
    return text.format(*args) if args else text


def builtin_param(text):
    """text as one quoted parameter of a builtin (CUtil::SplitParams)."""
    return '"' + text.replace('\\', '\\\\').replace('"', '\\"') + '"'


def log(txt, level=xbmc.LOGINFO):
    xbmc.log(f'{ADDON_ID}: {txt}', level=level)


def notify(msg, icon=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, icon, 3000)


def disk_used_percent():
    """How full the PVR backend's disk is, 0-100, or None when it isn't reported.

    PVR.BackendDiskSpaceProgr is a number with no label form ($INFO and getInfoLabel give
    nothing), so it is found by bisecting with Integer.IsGreater. It is 255 when unreported."""
    info = 'PVR.BackendDiskSpaceProgr'
    if xbmc.getCondVisibility(f'Integer.IsGreater({info},100)'):
        return None
    low, high = 0, 100
    while low < high:
        mid = (low + high) // 2
        if xbmc.getCondVisibility(f'Integer.IsGreater({info},{mid})'):
            low = mid + 1
        else:
            high = mid
    return low


def kodi_major():
    try:
        return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except ValueError:
        return 0


def rpc():
    return Rpc(xbmc.executeJSONRPC)


def home():
    """Kodi's Home window, which holds the properties shared with the layouts and the skin."""
    return xbmcgui.Window(WINDOW_HOME)


def setting_int(key, default=0):
    try:
        return ADDON.getSettings().getInt(key)
    except (RuntimeError, TypeError, AttributeError):
        return default


def setting_bool(key, default=False):
    try:
        return ADDON.getSettings().getBool(key)
    except (RuntimeError, TypeError, AttributeError):
        return default


# Home property, set once the PVR has given us recordings this session (or we gave up waiting)
PVR_READY = 'script.centerstage.pvr_ready'
PVR_WAIT = 60   # seconds to wait for a PVR add-on that's still starting, once a session


def pvr_starting(rpc):
    """Whether the PVR is still starting: recordings are wanted and a PVR add-on is on, but Kodi
    has none yet. Kodi starts the PVR before the add-on has connected (pvr.mythtv takes a while)
    and loads all of an add-on's recordings at once, so there are none until they're all in."""
    props = home()
    if props.getProperty(PVR_READY) or not setting_bool('include_pvr', True) \
            or not xbmc.getCondVisibility('System.HasPVRAddon'):
        return False
    try:
        if pvr.recordings(rpc):
            props.setProperty(PVR_READY, 'true')
            return False
    except RpcError:
        pass  # the PVR manager hasn't started
    return True


def wait_for_pvr(rpc, stop=None):
    """Wait while the PVR is starting, for at most PVR_WAIT seconds (then not again this session,
    since a backend with no recordings looks the same), or until stop is set."""
    monitor = xbmc.Monitor()
    end = time.monotonic() + PVR_WAIT
    while pvr_starting(rpc):
        if time.monotonic() > end:
            log('no PVR recordings yet; not waiting for them again')
            home().setProperty(PVR_READY, 'gave up')
            return
        if monitor.waitForAbort(0.5) or (stop is not None and stop.is_set()):
            return


def all_recordings(rpc):
    """Every PVR recording, or None with recordings turned off or the PVR not running."""
    if not setting_bool('include_pvr', True):
        return None
    try:
        return pvr.recordings(rpc)
    except RpcError as e:
        log(f'no PVR recordings: {e}')  # PVR disabled or not started yet
        return None


def recording_groups(rpc):
    """The PVR's recording groups (Default first), or [] with the PVR off."""
    return pvr.groups(all_recordings(rpc) or [])


def titles(store, recs, group):
    """The left list: the stored entries for group and the PVR series of recs (already limited
    to group), as the settings arrange them."""
    pvr_rows = pvr.series_entries(recs, store.hidden_pvr(), store.renames())
    return catalog.rows(store.entries(), pvr_rows, setting_int('sort_order', catalog.SORT_TITLE),
                        group, movies_title(store), newest_title(group))


def movies_title(store):
    """The "Movies" title's name (it can be renamed), or None when movies aren't grouped."""
    if not setting_bool('group_movies', True):
        return None
    return store.renames().get(MOVIES_ID) or tr('movies')


def set_home_properties():
    """Settings the layouts read, as Home window properties:
    - script.centerstage.panel / panel_dark: the panels' colours, from the panel_opacity setting
      (Estuary's panel tint, and the Default layout's flat colour). On Home because a texture's
      colour is read with no window context, so a property of our own window might not be found.
    - script.centerstage.stage: the empty stage picture, the layouts' fallback for a title's
      missing picture (a layout only finds our own images in its own skin folder's media).
    - script.centerstage.spinner: the busy spinner, shown while the PVR starts."""
    pct = min(100, max(0, setting_int('panel_opacity', 80)))
    alpha = f'{round(pct * 255 / 100):02X}'
    props = home()
    props.setProperty(f'{ADDON_ID}.panel', alpha + 'FFFFFF')
    props.setProperty(f'{ADDON_ID}.panel_dark', alpha + '181C22')
    props.setProperty(f'{ADDON_ID}.stage', STAGE_ART)
    props.setProperty(f'{ADDON_ID}.spinner', SPINNER)


def newest_title(group):
    """The "Newest" title's name, "<group> - Newest", or None when it's turned off."""
    if not (setting_bool('include_pvr', True) and setting_bool('show_newest', True)):
        return None
    return tr('newest', group_label(group))


def group_label(group):
    """None is every group."""
    return tr('all_groups') if group is None else group


def pick_group(heading, options, current=None):
    """A choice from options (None and group names). Returns (False, None) if cancelled."""
    pre = options.index(current) if current in options else 0
    n = xbmcgui.Dialog().select(heading, [group_label(g) for g in options], preselect=pre)
    return (True, options[n]) if n >= 0 else (False, None)


def pick_entry_group(rpc, current=''):
    """Which group a stored entry is shown in: "" for all of them. None if cancelled; "" without
    asking when there's only one group."""
    named = recording_groups(rpc)
    if len(named) < 2 and current in named + ['']:
        return ''
    options = sorted(set(named) | ({current} - {''}),
                     key=lambda g: (g != pvr.DEFAULT_GROUP, g.casefold())) + [None]
    ok, group = pick_group(tr('which_group'), options, current or None)
    return (group or '') if ok else None


def origin_label(entry):
    """Where an entry comes from, for the details pane."""
    if entry.source == LIBRARY:
        return tr('library')
    if entry.source == MOVIES:
        return ''
    if entry.source == NEWEST:
        return tr('pvr')
    if entry.source == PVR:
        return tr('pvr') + (' - ' + entry.origin if entry.origin else '')  # "PVR - BBC One"
    return entry.origin


def count_label(entry):
    """How many recordings (or movies) a title has, for under its name in the details pane."""
    if entry.source == MOVIES:
        n = len(entry.members)
        return tr('one_movie') if n == 1 else tr('n_movies', n)
    if entry.source in (PVR, NEWEST) and entry.count:
        return tr('one_recording') if entry.count == 1 else tr('recordings', entry.count)
    return ''


def listitem_art(art):
    art = dict(art)
    poster = art.get('poster') or art.get('tvshow.poster') or art.get('season.poster')
    thumb = art.get('thumb')
    if thumb in (None, '', poster):
        # the picture's place is 16:9: a poster (a show's or movie's thumb) only if nothing's wide
        thumb = art.get('landscape') or art.get('fanart') or art.get('tvshow.fanart') or thumb
    thumb = thumb or art.get('landscape') or art.get('icon')
    if not poster:
        poster = thumb
    if not thumb:
        thumb = art.get('fanart') or poster
    art['poster'] = poster or ''
    art['thumb'] = thumb or ''
    art.setdefault('fanart', art.get('tvshow.fanart') or '')
    return {k: v for k, v in art.items() if v}


def title_art(entry):
    """A title's art; the empty stage when it has no picture."""
    art = listitem_art(entry.art)
    if not art.get('thumb'):
        art['thumb'] = STAGE_ART
    return art


def entry_listitem(entry):
    title = plain(entry.display_title)  # titles are never coloured, whatever the source sent
    li = xbmcgui.ListItem(title, offscreen=True)
    li.setArt(title_art(entry))
    tag = li.getVideoInfoTag()
    tag.setTitle(title)
    tag.setPlot(entry.title_plot)
    if entry.year:
        tag.setYear(entry.year)
    tag.setMediaType('movie' if entry.kind == MOVIE else 'tvshow')
    li.setProperty('entry_id', entry.id)
    li.setProperty('origin', origin_label(entry))
    li.setProperty('count', count_label(entry))
    return li


def _strftime(fmt, when):
    try:
        return time.strftime(fmt, when)
    except ValueError:
        return ''


def _date_time(text, region):
    """An Episode.date as (date in the user's format for region, "dateshort" or "datelong";
    time without seconds, or '' when it has none)."""
    parsed = parse_date(text)
    if not parsed:
        return '', ''
    when, has_time = parsed
    clock = _strftime(xbmc.getRegion('time').replace(':%S', ''), when) if has_time else ''
    return _strftime(xbmc.getRegion(region), when), clock


def short_date(text):
    """For the episode list: the date, and the time when it has one (recordings)."""
    return '  '.join(p for p in _date_time(text, 'dateshort') if p)


def episode_status(ep):
    """Length, then watched or the time left."""
    parts = []
    length = ep.runtime or int(ep.total)
    if length:
        parts.append(format_time(length))
    if ep.playcount > 0:
        parts.append(tr('watched'))
    elif ep.resume > 0 and ep.total > ep.resume:
        parts.append(tr('left', format_time(ep.total - ep.resume)))
    return ' · '.join(parts)


def episode_details(ep):
    """The grey lines at the top right of the details pane: where it's from ("PVR - BBC One" for
    a recording, the add-on's name for an add-on's item); the date; then the time, length and
    watched state. (Date and time on one line wrapped badly.)"""
    if ep.is_folder:
        return ep.label2
    day, clock = _date_time(ep.date, 'datelong')
    last = ' · '.join(p for p in (clock, episode_status(ep)) if p)
    source = f"{tr('pvr')} - {ep.channel}" if ep.channel else ep.origin
    return '[CR]'.join(p for p in (source, day, last) if p)


def episode_label(ep):
    """"Season 1, Episode 2" for an episode with no name of its own, else its label; after
    "Series · " in the "Newest" title, where the series are mixed."""
    label = ep.label
    if ep.untitled and not ep.is_folder and ep.episode > 0:
        if ep.season >= 0:
            label = tr('season_episode', ep.season, ep.episode)
        else:
            label = tr('episode_n', ep.episode)
    return f'{ep.show} · {label}' if ep.show else label


def details_name(ep):
    """The episode's name in the details pane: "S1 E02 · Name" (the row has just the name), and
    never coloured (only the row keeps pvr.mythtv's colour for damaged recordings)."""
    name = plain(episode_label(ep))
    code = '' if ep.untitled or ep.is_folder else details_code(ep.season, ep.episode)
    if not code:
        return name
    return code if name == episode_code(ep.season, ep.episode) else f'{code} · {name}'


def episode_listitem(ep):
    li = xbmcgui.ListItem(episode_label(ep), ep.label2 if ep.is_folder else short_date(ep.date),
                          offscreen=True)
    li.setProperty('name', details_name(ep))
    if ep.parent:
        li.setIsFolder(True)
        li.setProperty('parent', 'true')
        return li
    art = listitem_art(ep.art)
    li.setArt(art)
    # the layouts' fallback for a picture that's missing or won't load (a PVR preview mythbackend
    # couldn't make): the series' fanart, as in Kodi's recordings window, then the empty stage
    li.setProperty('fallback', art.get('fanart') or STAGE_ART)
    li.setIsFolder(ep.is_folder)
    tag = li.getVideoInfoTag()
    tag.setTitle(plain(ep.title or ep.label))
    tag.setPlot(ep.plot)
    if ep.media_type:
        tag.setMediaType(ep.media_type)
    if ep.season >= 0:
        tag.setSeason(ep.season)
    if ep.episode >= 0:
        tag.setEpisode(ep.episode)
    tag.setPlaycount(ep.playcount)
    if ep.runtime:
        tag.setDuration(ep.runtime)
    if ep.resume > 0 and ep.total > 0:
        tag.setResumePoint(ep.resume, ep.total)
    if ep.date:
        tag.setFirstAired(ep.date[:10])
    li.setProperty('details', episode_details(ep))
    li.setProperty('watched', 'true' if ep.playcount > 0 else '')
    return li
